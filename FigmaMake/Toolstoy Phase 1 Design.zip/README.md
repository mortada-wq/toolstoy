
  # Toolstoy Phase 1 Design

  This is a code bundle for Toolstoy Phase 1 Design. The original project is available at https://www.figma.com/design/MYqNqnTcD1jPtznuq2XSw4/Toolstoy-Phase-1-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  